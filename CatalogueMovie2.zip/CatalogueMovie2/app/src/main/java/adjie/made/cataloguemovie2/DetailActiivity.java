package adjie.made.cataloguemovie2;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import adjie.made.cataloguemovie2.Model.MoviesModel;

public class DetailActiivity extends AppCompatActivity {
    public static String KEY_ITEM = "item";
    private TextView tvDetailJudul, tvDetailOverview, tvDetailRilis;
    private ImageView imgDetailFilm;

    private MoviesModel moviesModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_actiivity);

        tvDetailJudul = (TextView)findViewById(R.id.tvDetailJudul);
        tvDetailOverview = (TextView)findViewById(R.id.tvDetailOverview);
        tvDetailRilis = (TextView)findViewById(R.id.tvDetailRilis);
        imgDetailFilm = (ImageView)findViewById(R.id.imgDetailFilm);

        moviesModel = (MoviesModel)getIntent().getParcelableExtra(KEY_ITEM);
        tvDetailJudul.setText(moviesModel.getTitle());
        tvDetailOverview.setText(moviesModel.getOverview());

        getSupportActionBar().setTitle(getResources().getString(R.string.name_bar_detail));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        SimpleDateFormat formatTanggal = new SimpleDateFormat("yyyy-MM-dd");

        try {
            Date tanggal = formatTanggal.parse(moviesModel.getRelease_date());
            SimpleDateFormat newFormatDate =  new SimpleDateFormat("EEEE, dd MMM yyyy");
            tvDetailRilis.setText(newFormatDate.format(tanggal));
        }catch (ParseException e){
            e.printStackTrace();
        }

        Glide.with(this).load("http://image.tmdb.org/t/p/w185"+moviesModel.getPoster_path()).into(imgDetailFilm);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == android.R.id.home){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
}
